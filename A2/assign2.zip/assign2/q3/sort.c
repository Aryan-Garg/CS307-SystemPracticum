#include <stdio.h>
#include <pthread.h>
#include <time.h>
#include<stdlib.h>
#define BILLION 1E9

int no_of_threads;
int *arr;
int MAX;
void merge(int low, int mid, int high)
{
    int* left = (int *)malloc(sizeof(int)*(mid-low+1));
    int* right = (int *)malloc(sizeof(int)*(high-mid));
 
    // n1 is size of left part and n2 is size
    // of right part
    int n1 = mid - low + 1, n2 = high - mid, i, j;
 
    // storing values in left part
    for (i = 0; i < n1; i++)
        left[i] = arr[i + low];
 
    // storing values in right part
    for (i = 0; i < n2; i++)
        right[i] = arr[i + mid + 1];
 
    int k = low;
    i = j = 0;
 
    // merge left and right in ascending order
    while (i < n1 && j < n2) {
        if (left[i] <= right[j])
            arr[k++] = left[i++];
        else
            arr[k++] = right[j++];
    }
 
    // insert remaining values from left
    while (i < n1) {
        arr[k++] = left[i++];
    }
 
    // insert remaining values from right
    while (j < n2) {
        arr[k++] = right[j++];
    }
}
 
// merge sort function
void merge_sort(int low, int high)
{
    // calculating mid point of array
    int mid = low + (high - low) / 2;
    if (low < high) {
 
        // calling first half
        merge_sort(low, mid);
 
        // calling second half
        merge_sort(mid + 1, high);
 
        // merging the two halves
        merge(low, mid, high);
    }
}
 
// thread function for multi-threading
void* merge_sorting(void* arg)
{
    // which part out of 4 parts
    int thread_part = *((int *)arg);
 
    // calculating low and high
    int low = thread_part * (MAX / no_of_threads);
    int high = (thread_part + 1) * (MAX / no_of_threads) - 1;
 
    // evaluating mid point
    int mid = low + (high - low) / 2;
    if (low < high) {
        merge_sort(low, mid);
        merge_sort(mid + 1, high);
        merge(low, mid, high);
    }
}

int main(int argc, char *argv[])
{
	FILE *infile = NULL;
	infile = fopen (argv[1], "r");
	if (NULL == infile) {
		perror ("fopen");
		return -1;
	}
	arr = (int *)malloc(sizeof(int)*100);
	int count = 0, arrsize = 100;
	int val;
	while (!feof (infile)) {
		fscanf (infile, "%dn", &val); /* fetch value */
		count++;
		if(count>arrsize){
			arr = (int *)realloc(arr, sizeof(int)*(arrsize+100));
			arrsize+=100;
		}
		arr[count-1]=val;
	}
	printf("Count: %d\n",count);
	MAX=count;

    clock_t t1, t2;
 
    
    no_of_threads = atoi(argv[2]);
    int block = count/no_of_threads;
    pthread_t threads[no_of_threads];
	
	struct timespec requestStart, requestEnd;
	clock_gettime(CLOCK_REALTIME, &requestStart);
    for (int i = 0; i < no_of_threads; i++){
    	int *arg = (int*)malloc(sizeof(*arg));
		*arg = i;
		pthread_create(&threads[i], NULL, merge_sorting,arg);
	}
        
    for (int i = 0; i < no_of_threads; i++)
        pthread_join(threads[i], NULL);
    int prev=0;
    for(int i=0; i<count; i+=block){
    	prev=i;
    	if(i>0){
    		if(i+block-1<count){
    			merge(0,i-1,i+block-1);
			}
			else{
				merge(0,i-1,count-1);
			}
			
		}
	}
	clock_gettime(CLOCK_REALTIME, &requestEnd);
	
    int flag=0;
    for(int i=0; i<count-1; i++){
    	if(arr[i]>arr[i+1]){
    		flag=1;
    		break;
		}
	}
    // time taken by merge sort in seconds
    double timetaken = ( requestEnd.tv_sec - requestStart.tv_sec )+( requestEnd.tv_nsec - requestStart.tv_nsec )/BILLION;
    printf("Time taken: %f\n",timetaken);
    printf("Count: %d\n",count);
    printf("Flag: %d\n",flag);
    return 0;
}
