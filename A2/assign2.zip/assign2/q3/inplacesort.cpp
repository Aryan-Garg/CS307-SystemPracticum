#include <stdio.h>
#include <pthread.h>
#include <time.h>
#include<stdlib.h>
#include<bits/stdc++.h>
#define BILLION 1E9

int no_of_threads;
int *arr;
int MAX;
void merge(int low, int mid, int high)
{
    int maxval = std::max(arr[mid], arr[high]) + 1;
    int i = low, j = mid + 1, k = low;
    while (i <= mid && j <= high && k <= high) {
        int ele1 = arr[i] % maxval;
        int ele2 = arr[j] % maxval;
        if (ele1 <= ele2) {
            arr[k] += (ele1 * maxval);
            i++;
            k++;
        }
        else {
            arr[k] += (ele2 * maxval);
            j++;
            k++;
        }
    }
    while (i <= mid) {
        int ele = arr[i] % maxval;
        arr[k] += (ele * maxval);
        i++;
        k++;
    }
    while (j <= high) {
        int ele = arr[j] % maxval;
        arr[k] += (ele * maxval);
        j++;
        k++;
    }
    for (int i = low; i <= high; i++){
    	arr[i] = arr[i]/maxval;
	}
}
 
//Merge sort function
void merge_sort(int low, int high){
    int mid = low + (high - low) / 2;
    if (low < high) {
        merge_sort(low, mid);
        merge_sort(mid + 1, high);
        merge(low, mid, high);
    }
}
 
//Thread function to calculate the particular thread
void* merge_sorting(void* arg){
    //identifying the thread
    int thread_part = *((int *)arg);
    int low = thread_part * (MAX / no_of_threads);
    int high = (thread_part + 1) * (MAX / no_of_threads) - 1;
    int mid = low + (high - low) / 2;
    if (low < high) {
        merge_sort(low, mid);
        merge_sort(mid + 1, high);
        merge(low, mid, high);
    }
    return NULL;
}

int main(int argc, char *argv[]){
	FILE *infile = NULL;
	//Opening the file given as input
	infile = fopen (argv[2], "r");
	if (NULL == infile) {
		perror ("fopen");
		return -1;
	}
	//Dynamically allocating the array to store the elements
	arr = (int *)malloc(sizeof(int)*1);
	int count = 0, arrsize = 1;
	int val;
	//Reading the file line by line
	while (!feof (infile)) {
		fscanf (infile, "%d ", &val); /* fetch value */
		count++;
		if(count>arrsize){
			//reallocating the space
			arr = (int *)realloc(arr, sizeof(int)*(arrsize+1));
			arrsize+=1;
		}
		arr[count-1]=val;
	}
	fclose(infile);
	//printf("Count: %d\n",count);
	MAX=count;
    clock_t t1, t2;
    no_of_threads = atoi(argv[1]);
    int block = count/no_of_threads;
    pthread_t threads[no_of_threads];
	
	//Calculating the execution time 
	struct timespec requestStart, requestEnd;
	clock_gettime(CLOCK_REALTIME, &requestStart);
    //Creating the threads
	for (int i = 0; i < no_of_threads; i++){
    	int *arg = (int*)malloc(sizeof(*arg));
		*arg = i;
		pthread_create(&threads[i], NULL, merge_sorting,arg);
	}
    //Joining the threads
    for (int i = 0; i < no_of_threads; i++){
    	pthread_join(threads[i], NULL);
	}
	//Merging the sorted threads
    for(int i=0; i<count; i+=block){
    	if(i>0){
    		if(i+block-1<count){
    			merge(0,i-1,i+block-1);
			}
			else{
				merge(0,i-1,count-1);
			}
			
		}
	}
	clock_gettime(CLOCK_REALTIME, &requestEnd);
	
    int flag=0;
    for(int i=0; i<count-1; i++){
    	if(arr[i]>arr[i+1]){
    		flag=1;
    		break;
		}
	}
    // time taken by merge sort in seconds
    double timetaken = ( requestEnd.tv_sec - requestStart.tv_sec )+( requestEnd.tv_nsec - requestStart.tv_nsec )/BILLION;
//    printf("Time taken: %f\n",timetaken);
//    if(!flag){
//    	printf("Sorted correctness pass!!\n");
//	}else{
//		printf("Sorted correctness failed!!\n");
//	}
	
	printf("Total execution time : %f\n",timetaken);
    
    //Writing the sorted elements to the output file
    FILE *outputfile;
    outputfile = fopen(argv[3],"w");
    for(int i = 0 ; i < count ; i++ ) {
   	  char buffer[11];
   	  sprintf(buffer, "%d ", arr[i]);
      fputs(buffer, outputfile) ;
   	}
   	//Freeing the arr
    delete arr;
    return 0;
}
